<?php

namespace UCSP;

class ApiException extends \Exception {
}