<?php require_once(PROJECT_PATH.'/includes/initialize.php'); ?>
<style type="text/css">
  <?php // ## UCRM requires file paths, Using PHP include instead of HTML tags to avoid relative URL ?>
  <?php include(PROJECT_PATH."/public/vendor-463d4d71894dfde19d720aa6b937502f.css"); ?>
  <?php include(PROJECT_PATH."/public/ucrm-client-signup-form-500a5c0e9df67704f365edc02f483591.css"); ?>
</style>

<?php
  // file_put_contents(PROJECT_PATH.'/data/plugin.log', '', LOCK_EX);
  $service_json_file = PROJECT_PATH.'/data/services_filter.json'; 
  $data = [];

  if (file_exists($service_json_file)) {
    $jsonString = file_get_contents($service_json_file);
    $data = json_decode($jsonString, true);
  }

  if (empty($data)) {
    $data =  [
      "no_service_selected" => true
    ];
  }
  $isAdmin = UcrmHandler::isAdmin();
  if ($isAdmin) {
?>

<div class="container-fluid">
  <div class="row py-4">
    <div class="col-auto">
      <pre>
        <?php print_r($data); ?>
      </pre>
      <p>
        Welcome Admin
      </p>
    </div>
  </div>
</div>


<?php
    $newJsonString = json_encode($data);
    file_put_contents($service_json_file, $newJsonString);
  } else {
    echo 'You do not have permission to access this page.';
  }

?>
